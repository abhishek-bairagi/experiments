class AddAgent:
    description = "Adds two numbers. Arguments: a (int), b (int)."

    def run(self, a, b,session_id = None):
        return f"Sum: {a + b}"
