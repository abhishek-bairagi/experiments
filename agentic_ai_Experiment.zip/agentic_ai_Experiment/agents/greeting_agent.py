class GreetingAgent:
    description = "Responds with a greeting. Argument: name (str)."

    def run(self, name):
        return f"Hello {name}, hope you're having a great day!"
