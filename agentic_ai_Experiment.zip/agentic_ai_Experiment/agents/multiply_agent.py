class MultiplyAgent:
    description = "Multiplies two numbers. Arguments: a (int), b (int)."

    def run(self, a, b):
        return f"Product: {a * b}"
