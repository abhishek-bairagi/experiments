from session_manager import SessionManager
from llm import generate_text
import json

class MathFormAgent:
    description = "Handles math (add/sub) via form. Args: input (str), session_id (str)."

    def extract_slots(self, message, session_id):
        prompt = f"""
Extract 'op' (add/sub), 'a', and 'b' from this message:
"{message}"

Respond as:
{{"op": "add", "a": 3, "b": 4}}
"""
        try:
            slots = json.loads(generate_text(prompt))
            SessionManager.update(session_id, slots)
        except:
            pass

    def run(self, input, session_id):
        session = SessionManager.get(session_id)
        self.extract_slots(input, session_id)

        if "op" not in session:
            return {"message": "What operation? (add or sub)", "session_id": session_id}
        if "a" not in session:
            return {"message": "Enter a:", "session_id": session_id}
        if "b" not in session:
            return {"message": "Enter b:", "session_id": session_id}

        op, a, b = session["op"], session["a"], session["b"]
        result = a + b if op == "add" else a - b
        return {"message": f"Result: {result}", "session_id": session_id}
