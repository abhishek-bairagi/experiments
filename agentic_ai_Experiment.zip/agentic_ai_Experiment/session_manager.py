class SessionManager:
    _sessions = {}

    @classmethod
    def get(cls, session_id):
        return cls._sessions.setdefault(session_id, {})

    @classmethod
    def update(cls, session_id, data):
        cls._sessions[session_id].update(data)

    @classmethod
    def get_all(cls):
        return cls._sessions
