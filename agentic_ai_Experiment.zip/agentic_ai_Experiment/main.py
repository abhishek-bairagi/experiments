from fastapi import FastAPI, Request
from pydantic import BaseModel
from brain.brain import Brain
import uvicorn
from session_manager import SessionManager

app = FastAPI(docs_url="/docs")
brain = Brain()

class Query(BaseModel):
    message: str
    session_id: str

@app.post("/query")
def query(data: Query):
    return brain.run(data.message, data.session_id)

@app.get("/session/{session_id}")
def get_session(session_id: str):
    return SessionManager.get(session_id)



if __name__ == "__main__":
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
