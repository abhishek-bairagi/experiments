import os
import importlib
import agents

def load_agents():
    agents_dict = {}
    for filename in os.listdir("agents"):
        if filename.endswith(".py") and filename != "__init__.py":
            module_name = f"agents.{filename[:-3]}"
            module = importlib.import_module(module_name)
            for attr in dir(module):
                obj = getattr(module, attr)
                if isinstance(obj, type) and hasattr(obj, 'description'):
                    agents_dict[obj.__name__] = obj()
    return agents_dict
