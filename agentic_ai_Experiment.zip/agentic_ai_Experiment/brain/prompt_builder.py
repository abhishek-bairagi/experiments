def build_prompt(user_input, agents):
    descriptions = "\n".join([f"{k}: {v.description}" for k, v in agents.items()])
    return f"""
You are a smart router AI. Based on user input, decide which agent to call and what arguments to pass.

Agents:
{descriptions}

User Message:
\"{user_input}\"

Respond in this JSON format:
{{
  "agent": "<AgentClassName>",
  "args": {{
    "a": 3,
    "b": 5
  }}
}}
"""
