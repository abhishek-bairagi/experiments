from agent_loader import load_agents
from brain.prompt_builder import build_prompt
from llm import generate_text
import json

class Brain:
    def __init__(self):
        self.agents = load_agents()

    def run(self, user_input, session_id):
        prompt = build_prompt(user_input, self.agents)
        response = generate_text(prompt)

        try:
            print(response)
            parsed = json.loads(response)
            agent_name = parsed["agent"]
            args = parsed.get("args", {})
            args["session_id"] = session_id

            agent = self.agents.get(agent_name)
            if agent:
                return agent.run(**args)
            else:
                return {"error": f"Agent '{agent_name}' not found."}
        except Exception as e:
            return {"error": str(e), "raw_response": response}
